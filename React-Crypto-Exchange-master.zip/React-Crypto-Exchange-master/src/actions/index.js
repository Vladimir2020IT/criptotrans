import {singIN, singOUT} from './account'
import {switchSingINModal, switchResetPasswordModal, switchSingUPModal} from './modals'


export {
    singIN,
    singOUT,
    switchResetPasswordModal,
    switchSingUPModal,
    switchSingINModal
}