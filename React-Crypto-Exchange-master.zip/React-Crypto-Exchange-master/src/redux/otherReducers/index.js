import { routerReducer } from 'react-router-redux'


const reducers = {
    router: routerReducer,
};

export default reducers