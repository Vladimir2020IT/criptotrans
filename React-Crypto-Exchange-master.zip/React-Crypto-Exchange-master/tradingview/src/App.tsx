import * as React from 'react';
import { TVChartContainer } from './components/TVChartContainer/index';

class App extends React.Component {

	render() {

		return (
			<TVChartContainer />
		);
	}
}

export default App;