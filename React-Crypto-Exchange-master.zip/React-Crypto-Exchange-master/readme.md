
![APMLicense](https://img.shields.io/apm/l/vim-mode.svg)

# React-Crypto-Exchange
* SPA
* Animations
* Dynamics routing

# Use of technology
* React
* Redux
* React-router
* Aphrodite
* Reactstrap
* Redux-thunk

![](demo.png)
